# VIT Internship - Ethnus MERN Assignment

## Student Details
- **Name:** Kartikey Vishwakarma  
- **Registration No.:** 22BHI10079  
- **Email:** [kartikeyvishwakarma2022@vitbhopal.ac.in](mailto:kartikeyvishwakarma2022@vitbhopal.ac.in)  

## Completed Tasks  
### ✅ HTML  
### ✅ CSS  
### ✅ Bootstrap  
### ✅ JavaScript  
 
